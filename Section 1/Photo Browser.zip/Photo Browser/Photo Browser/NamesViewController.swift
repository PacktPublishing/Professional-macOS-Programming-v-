//NamesViewController.swift
//Photo Browser 
	
//Created by Dee Odus.
//Copyright Dee Odus (Appkoder.com). All Rights Reserved.

import Cocoa

class NamesViewController: NSViewController, NSTableViewDataSource, NSTableViewDelegate{
    
    @IBOutlet var tableView: NSTableView!
    var namesOfFlowers = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        namesOfFlowers.append("Rose")
        namesOfFlowers.append("Lily")
        namesOfFlowers.append("Sunflower")
        namesOfFlowers.append("Marigold")
        namesOfFlowers.append("Tulips")
    }
    
    func tableView(_ tableView: NSTableView, viewFor tableColumn: NSTableColumn?, row: Int) -> NSView? {
        let view = tableView.makeView(withIdentifier: tableColumn!.identifier, owner: self) as? NSTableCellView
        
        view?.textField?.stringValue = namesOfFlowers[row]
        
        return view
    }
    
    func numberOfRows(in tableView: NSTableView) -> Int {
        
        return namesOfFlowers.count
    }
    
}
