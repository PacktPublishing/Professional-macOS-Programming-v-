//ViewController.swift
//AnimationApp 
	
//Created by Dee Odus.
//Copyright Dee Odus (Appkoder.com). All Rights Reserved.

import Cocoa

class ViewController: NSViewController {

    @IBOutlet var imageView: NSImageView!
    
    override func viewDidAppear() {
        super.viewDidAppear()
        
        //NSAnimationContext.current.duration = 5
        //self.view.animator().alphaValue = 0.1
        //self.view.wantsLayer = true
        //self.view.animator().layer?.backgroundColor = NSColor.yellow.cgColor
    }


    @IBAction func animate(_ sender: Any) {
        
        thirdAnimation()
    }
    
    func firstAnimation(){
        
        NSAnimationContext.current.duration = 5
        NSAnimationContext.current.allowsImplicitAnimation = true
        imageView.animator().layer?.borderColor = NSColor.red.cgColor
        imageView.animator().layer?.borderWidth = 20
    }
    
    func secondAnimation(){
        
        NSAnimationContext.runAnimationGroup({ (context) in
            
            //animation code
            context.allowsImplicitAnimation = true
            context.duration = 3
            
            imageView.animator().frameCenterRotation = 90
            imageView.animator().alphaValue = 0.2
        }) {
            
            //completion handler
            
            NSAnimationContext.current.duration = 3
            self.imageView.animator().frameCenterRotation = 0
            self.imageView.animator().alphaValue = 1.0
        }
    }
    
    func thirdAnimation(){
        
        /*let opacityAnimation = CABasicAnimation(keyPath: "opacity")
        opacityAnimation.fromValue = 1
        opacityAnimation.toValue = 0.2
        opacityAnimation.duration = 5
        
        imageView.layer?.opacity = 0.2
        imageView.layer?.add(opacityAnimation, forKey: nil)*/
        
        /*let scaleAnimation = CABasicAnimation()
        scaleAnimation.keyPath = "transform.scale"
        scaleAnimation.fromValue = 1.0
        scaleAnimation.toValue = 1.3
        scaleAnimation.autoreverses = true
        scaleAnimation.repeatCount = 20
        
        imageView.layer?.add(scaleAnimation, forKey: nil)*/
        
        let moveAnimation = CABasicAnimation()
        moveAnimation.keyPath = "position.y"
        moveAnimation.fromValue = imageView.frame.origin.y
        moveAnimation.toValue = imageView.frame.origin.y + 30
        moveAnimation.autoreverses = true
        moveAnimation.repeatCount = 30
        
        imageView.layer?.add(moveAnimation, forKey: nil)
    }
    
}

