//ViewController.swift
//QuickNoteApp 
	
//Created by Dee Odus.
//Copyright Dee Odus (Appkoder.com). All Rights Reserved.

import Cocoa

class ViewController: NSViewController {

    @IBOutlet var textView: NSTextView!
    let defaults = UserDefaults.standard
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
        let text = defaults.string(forKey: "text") ?? ""
        textView.string = text
        
        NSEvent.addLocalMonitorForEvents(matching: .keyDown, handler: keyDown)
    }
    
    func keyDown(event: NSEvent) -> NSEvent{
        
        let commandPressed = event.modifierFlags.contains(.command)
        print(commandPressed)
        
        if commandPressed && event.keyCode == 1{
            save(self)
        }
        
        if commandPressed && event.keyCode == 8{
            
            clear(self)
        }
        
        return event
    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }

    @IBAction func save(_ sender: Any) {
        
        let text = textView.string
        defaults.set(text, forKey: "text")
    }
    
    @IBAction func clear(_ sender: Any) {
        
        let alert = NSAlert()
        alert.messageText = "Clear Text?"
        alert.informativeText = "Are you sure you want to clear this text, this action cannot be reversed"
        alert.addButton(withTitle: "Clear?")
        alert.addButton(withTitle: "Cancel")
        
        let response = alert.runModal()
        
        switch response{
            
        case NSApplication.ModalResponse.alertFirstButtonReturn:
            
            textView.string = ""
            defaults.set(nil, forKey: "text")
            
        case NSApplication.ModalResponse.alertSecondButtonReturn:
            break
        default:
            break
        }
    }
}

