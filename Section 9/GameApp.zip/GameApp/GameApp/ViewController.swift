//ViewController.swift
//GameApp 
	
//Created by Dee Odus.
//Copyright Dee Odus (Appkoder.com). All Rights Reserved.

import Cocoa
import SpriteKit

class ViewController: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        if let skView = self.view as? SKView{
            
            let gameScene = GameScene(size: skView.bounds.size)
            gameScene.scaleMode = .aspectFill
            
            skView.presentScene(gameScene)
            
            skView.showsFPS = true
            skView.showsNodeCount = true
        }
    }


}

