//ViewController.swift
//BrowserApp 
	
//Created by Dee Odus.
//Copyright Dee Odus (Appkoder.com). All Rights Reserved.

import Cocoa
import WebKit

class ViewController: NSViewController, WKNavigationDelegate {

    @IBOutlet var webView: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()

        webView.navigationDelegate = self
    }

    @IBAction func enterKeyPressed(_ sender: NSTextField){
        
        let urlString = sender.stringValue
        guard let url = URL(string: urlString) else { return }
        let urlRequest = URLRequest(url: url)
        webView.load(urlRequest)
        
    }
    
    @IBAction func navigationButtonClicked(_ sender: NSSegmentedControl){
        
        if sender.selectedSegment == 0{
            
            webView.goBack()
        }else{
            webView.goForward()
        }
    }
    
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
        
        let currentUrl = webView.url?.absoluteString ?? ""
        guard let windowController = view.window?.windowController as? WindowController else { return }
        let textField = windowController.urlTextfield
        textField?.stringValue = currentUrl
    }

}

