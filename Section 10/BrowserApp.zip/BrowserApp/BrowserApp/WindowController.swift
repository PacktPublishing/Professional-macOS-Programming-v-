//WindowController.swift
//BrowserApp 
	
//Created by Dee Odus.
//Copyright Dee Odus (Appkoder.com). All Rights Reserved.

import Cocoa

class WindowController: NSWindowController {

    @IBOutlet var segmentedControl: NSSegmentedControl!
    @IBOutlet var urlTextfield: NSTextField!
    
    override func windowDidLoad() {
        super.windowDidLoad()
    
        window?.titleVisibility = .hidden
    }

}
