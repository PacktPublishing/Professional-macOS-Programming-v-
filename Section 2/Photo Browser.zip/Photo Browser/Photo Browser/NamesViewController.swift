//NamesViewController.swift
//Photo Browser 
	
//Created by Dee Odus.
//Copyright Dee Odus (Appkoder.com). All Rights Reserved.

import Cocoa

class NamesViewController: NSViewController, NSTableViewDataSource, NSTableViewDelegate{
    
    @IBOutlet var tableView: NSTableView!
    var namesOfFlowers = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let fileManager = FileManager.default
        guard let path = Bundle.main.resourcePath else { return }
        let items = try! fileManager.contentsOfDirectory(atPath: path)
        
        for item in items{
            
            if item.hasSuffix("png"){
                
                let flowerName = item.components(separatedBy: ".").first ?? ""
                namesOfFlowers.append(flowerName)
            }
        }
        
    }
    
    func tableViewSelectionDidChange(_ notification: Notification) {
        
        guard let splitViewVC = parent as? NSSplitViewController else { return }
        
        guard let photoVC = splitViewVC.children[1] as? PhotoViewController else { return }
        
        let flowerName = namesOfFlowers[tableView.selectedRow]
        photoVC.imageSelected(flowerName: flowerName)
    }
    
    func tableView(_ tableView: NSTableView, viewFor tableColumn: NSTableColumn?, row: Int) -> NSView? {
        let view = tableView.makeView(withIdentifier: tableColumn!.identifier, owner: self) as? NSTableCellView
        
        view?.textField?.stringValue = namesOfFlowers[row]
        
        return view
    }
    
    func numberOfRows(in tableView: NSTableView) -> Int {
        
        return namesOfFlowers.count
    }
    
}
